import Vue from "vue";
import { GridPlugin, Edit, Page, Toolbar, ForeignKey } from "@syncfusion/ej2-vue-grids";
import { DataManager, UrlAdaptor } from "@syncfusion/ej2-vue-grids/node_modules/@syncfusion/ej2-data";
import CounterComponent from "../counter/counter";

Vue.use(GridPlugin);

let foreignKeyDatasource: object[] = [
    { employeeID: 1, firstName: "Nancy", lastName: "Davolio" },
    { employeeID: 2, firstName: "Andrew", lastName: "Fuller" },
    { employeeID: 3, firstName: "Janet", lastName: "Leverling" },
    { employeeID: 4, firstName: "Margaret", lastName: "Peacock" },
    { employeeID: 5, firstName: "Steven", lastName: "Buchanan" }
]

export default Vue.extend({
    data: () => {
        return {
            pageSettings: { pageSize: 12 },
            toolbar: ['Add', 'Edit', 'Delete', 'Update', 'Cancel'],
            foreignKeyData: foreignKeyDatasource,
            editSettings: { allowEditing: true, allowAdding: true, allowDeleting: true },
            cTemplate: function () {
                return {
                    template: Vue.component('columnTemplate', {
                        template: `<div class="image">
                            <input class="e-btn" type="button" :value="rowData"/>
                        </div>`,
                        data: function () {
                            return {
                                data: {}
                            }
                        },
                        computed: {
                            rowData: function () {
                                return (this as any).data.foreignKeyData.employeeID;
                            }
                        }
                    })
                }
            },
            data: new DataManager({
                url: "Home/UrlDatasource",
                updateUrl: "Home/Update",
                insertUrl: "Home/Insert",
                removeUrl: "Home/Delete",
                adaptor: new UrlAdaptor()
            }),
        };
    },
    methods: {
    },
    provide: {
        grid: [Edit, Page, Toolbar, ForeignKey]
    }
});
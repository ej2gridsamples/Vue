using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Syncfusion.EJ2.Base;

namespace asp_vue.Controllers
{
    public class HomeController : Controller
    {
        public static List<Employees> employees = new List<Employees>();
        public IActionResult Index()
        {
            if (employees.Count == 0)
            {
                BindForeignKeyDataSource();
            }
            return View();
        }

        public IActionResult Error()
        {
            ViewData["RequestId"] = Activity.Current?.Id ?? HttpContext.TraceIdentifier;
            return View();
        }
        public object BindForeignKeyDataSource()
        {
            employees.Add(new Employees(1, "Nancy", "Davolio"));
            employees.Add(new Employees(2, "Andrew", "Fuller"));
            employees.Add(new Employees(3, "Janet", "Leverling"));
            employees.Add(new Employees(4, "Margaret", "Peacock"));
            employees.Add(new Employees(5, "Steven", "Buchanan"));

            return employees;
        }
        public IActionResult UrlDatasource([FromBody]DataManagerRequest dm)
        {
            IEnumerable DataSource = OrdersDetails.GetAllRecords();
            List<string> str = new List<string>();
            DataOperations operation = new DataOperations();
            if (dm.Sorted != null && dm.Sorted.Count > 0) //Sorting
            {
                DataSource = operation.PerformSorting(DataSource, dm.Sorted);
            }
            if (dm.Where != null && dm.Where.Count > 0) //Filtering
            {
                DataSource = operation.PerformFiltering(DataSource, dm.Where, dm.Where[0].Operator);
            }
            int count = DataSource.Cast<OrdersDetails>().Count();
            if (dm.Skip != 0)
            {
                DataSource = operation.PerformSkip(DataSource, dm.Skip);   //Paging
            }
            if (dm.Take != 0)
            {
                DataSource = operation.PerformTake(DataSource, dm.Take);
            }
            return dm.RequiresCounts ? Json(new { result = DataSource, count = count }) : Json(DataSource);
        }
        public class OrdersDetails
        {
            public static List<OrdersDetails> order = new List<OrdersDetails>();
            public OrdersDetails()
            {

            }
            public OrdersDetails(int OrderID, string CustomerId, int EmployeeId, double Freight, string ShipCity)
            {
                this.OrderID = OrderID;
                this.CustomerID = CustomerId;
                this.EmployeeID = EmployeeId;
                this.Freight = Freight;
                this.ShipCity = ShipCity;
            }

            public static List<OrdersDetails> GetAllRecords()
            {
                if (order.Count() == 0)
                {
                    order.Add(new OrdersDetails(10248, "ALFKI", 1, 2.3, "Berlin"));
                    order.Add(new OrdersDetails(10249, "ANATR", 2, 3.3, "Madrid"));
                    order.Add(new OrdersDetails(10250, "ANTON", 3, 4.3, "Cholchester"));
                    order.Add(new OrdersDetails(10251, "BLONP", 4, 5.3, "Marseille"));
                    order.Add(new OrdersDetails(10252, "BOLID", 5, 6.3, "Tsawassen"));
                }
                return order;
            }

            public int? OrderID { get; set; }
            public string CustomerID { get; set; }
            public int EmployeeID { get; set; }
            public double? Freight { get; set; }
            public string ShipCity { get; set; }
        }

        public class Employees
        {
            public Employees()
            {

            }
            public Employees(int EmployeeID, string FirstName, string LastName)
            {
                this.EmployeeID = EmployeeID;
                this.FirstName = FirstName;
                this.LastName = LastName;
            }
            public int EmployeeID { get; set; }
            public string FirstName { get; set; }
            public string LastName { get; set; }
        }
    }
}
